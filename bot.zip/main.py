from aiogram import Bot, Dispatcher
from asyncio import run
from aiogram.types import BotCommand
from aiogram.filters import Command
from admin.delete_expense import delete_expense_handlers
from count import show_products
from functions import admin_callback_func, expense_callback_func, main_func, help, newuser_callback_func, product_callback_func, order_callback_func
from admin.delete_order import delete_order_handlers
from admin.delete_product import delete_product_handlers
from admin.delete_user import delete_user_register_handlers
from functions.main_func import start_bot, shutdown_bot
from admin.new_user import new_user_register_handlers
from count.storage import register_add_product_handlers
from count.orders import register_order_handlers
from count.expense import add_expense_handlers

# Initialize the Dispatcher
bot = Bot("5489574140:AAFHBQi9tVSzxNOPDRiaLO6J-FVwO_XXxwY")
dp = Dispatcher()

async def start():
    # Register startup and shutdown handlers
    dp.startup.register(start_bot)
    dp.shutdown.register(shutdown_bot)

    # Register command handlers
    dp.message.register(main_func.start_command_answer, Command("start"))
    dp.message.register(help.help_command_answer, Command("help"))
    dp.message.register(help.admin_command_answer, Command("admin"))
    dp.message.register(help.seller_command_answer, Command("sotuvchi"))
    dp.message.register(show_products.view_products_command, Command("view_products"))


    # This line registers the callback handler
    dp.callback_query.register(admin_callback_func.admin_handle_callback, 
                                lambda callback_query: callback_query.data in 
                                (admin_callback_func.ADMIN_MENU_CALLBACK, 
                                 admin_callback_func.DOWN_STORAGE_CALLBACK, 
                                 admin_callback_func.DOWN_USERS_CALLBACK, 
                                 admin_callback_func.DOWN_ORDERS_CALLBACK, 
                                 admin_callback_func.DOWN_EXPENSES_CALLBACK))
    
    dp.callback_query.register(newuser_callback_func.user_handle_callback, 
                                lambda callback_query: callback_query.data in 
                                (newuser_callback_func.NEW_ADMIN_CALLBACK, 
                                 newuser_callback_func.DELETE_USER_CALLBACK))
    
    dp.callback_query.register(product_callback_func.product_handle_callback, 
                                lambda callback_query: callback_query.data in 
                                (product_callback_func.DELETE_PRODUCT_CALLBACK,
                                 product_callback_func.ADD_PRODUCT_CALLBACK))
    dp.callback_query.register(order_callback_func.order_handle_callback, 
                                lambda callback_query: callback_query.data in 
                                (order_callback_func.DELETE_ORDER_CALLBACK,
                                 order_callback_func.ADD_ORDER_CALLBACK))

    dp.callback_query.register(expense_callback_func.expense_handle_callback, 
                                lambda callback_query: callback_query.data in 
                                (expense_callback_func.ADD_EXPENSE_CALLBACK,
                                 expense_callback_func.DELETE_EXPENSE_CALLBACK))

    # Register handlers from new_admin.py
    new_user_register_handlers(dp)

    # Register handlers from delete_user.py
    delete_user_register_handlers(dp)

    # Register handlers from new_product.py
    register_add_product_handlers(dp)

    # Register handlers from new_product.py
    register_order_handlers(dp)
    
    # Register handlers from new_product.py
    delete_product_handlers(dp)

    # Register handlers from new_product.py
    delete_order_handlers(dp)

    # Register handlers from new_product.py
    add_expense_handlers(dp)

    # Register handlers from new_product.py
    delete_expense_handlers(dp)

    # Initialize the bot  # Replace with your actual token
    await bot.set_my_commands([
        BotCommand(command="/help", description="Yordam"),
        BotCommand(command="/admin", description="AdminMenyu"),
        BotCommand(command="/sotuvchi", description="SotuvchiMenyu")
    ])

    # Start polling
    await dp.start_polling(bot, polling_timeout=1)

# Entry point of the script
if __name__ == "__main__":
    run(start())
