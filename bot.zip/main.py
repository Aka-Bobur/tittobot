from aiogram import Bot, Dispatcher
from asyncio import run
from aiogram.types import BotCommand
from aiogram.filters import Command
from admin import down_expenses, down_storage, down_orders, down_users
from count import show_products, storage, orders, expense
from functions import admin_callback_func, main_func, help, newuser_callback_func
from functions.main_func import start_bot, shutdown_bot
from admin.new_user import new_user_register_handlers
from count.storage import register_add_product_handlers
from count.orders import register_order_handlers
from count.expense import register_expense_handlers

# Initialize the Dispatcher
bot = Bot("7247747885:AAF--tLG7fNhK1fQzvCRXZ7y6FFh8IF8YVY")
dp = Dispatcher()

async def start():
    # Register startup and shutdown handlers
    dp.startup.register(start_bot)
    dp.shutdown.register(shutdown_bot)

    # Register command handlers
    dp.message.register(main_func.start_command_answer, Command("start"))
    dp.message.register(help.help_command_answer, Command("help"))
    dp.message.register(help.admin_command_answer, Command("admin"))
    dp.message.register(help.seller_command_answer, Command("sotuvchi"))
    dp.message.register(orders.add_order_command, Command("add_order"))
    dp.message.register(storage.add_product_command, Command("new_product"))
    dp.message.register(expense.add_expense_command, Command("new_expense"))
    dp.message.register(show_products.view_products_command, Command("view_products"))
    
    
    dp.message.register(down_users.download_users_command, Command("down_users"))
    dp.message.register(down_orders.download_orders_command, Command("down_orders"))
    dp.message.register(down_storage.download_products_command, Command("down_storage"))
    dp.message.register(down_expenses.download_expenses_command, Command("down_expenses"))
    

    # This line registers the callback handler
    dp.callback_query.register(admin_callback_func.admin_handle_callback, 
                                lambda callback_query: callback_query.data in 
                                (admin_callback_func.ADMIN_MENU_CALLBACK, 
                                 admin_callback_func.DOWN_STORAGE_CALLBACK, 
                                 admin_callback_func.DOWN_USERS_CALLBACK, 
                                 admin_callback_func.DOWN_ORDERS_CALLBACK, 
                                 admin_callback_func.DOWN_EXPENSES_CALLBACK))
    
    dp.callback_query.register(newuser_callback_func.start_handle_callback, 
                                lambda callback_query: callback_query.data == newuser_callback_func.NEW_ADMIN_CALLBACK)

    # Register handlers from new_admin.py
    new_user_register_handlers(dp)

    # Register handlers from new_product.py
    register_add_product_handlers(dp)

    # Register handlers from new_product.py
    register_order_handlers(dp)

    # Register handlers from new_product.py
    register_expense_handlers(dp)

    # Initialize the bot  # Replace with your actual token
    await bot.set_my_commands([
        BotCommand(command="/help", description="Yordam")
    ])

    # Start polling
    await dp.start_polling(bot, polling_timeout=1)

# Entry point of the script
if __name__ == "__main__":
    run(start())
