import aiosqlite, logging

async def connect_to_db():
    return await aiosqlite.connect('database.db')

async def is_user_admin_or_seller(user_id: int) -> bool:
    print(f"Checking admin/seller status for user ID: {user_id}")  # Print the user ID being checked
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT admin, seller FROM users WHERE telegram_user_id = ?", (user_id,)) as cursor:
            result = await cursor.fetchone()
            print(f"Fetched result for user {user_id}: {result}")  # Log the fetched result
        await conn.close()
        
        if result:
            is_admin = result[0].lower() == 'true'  # Check if user is admin
            is_seller = result[1].lower() == 'true'  # Check if user is seller
            logging.debug(f"User {user_id} admin status: {is_admin}, seller status: {is_seller}")
            return is_admin or is_seller  # Return True if the user is either an admin or seller
        else:
            logging.debug(f"User {user_id} not found in database.")
            return False
    except aiosqlite.Error as e:
        logging.error(f"Database error while checking admin/seller status for user {user_id}: {e}")
        return False
    except Exception as e:
        logging.error(f"Unexpected error while checking admin/seller status for user {user_id}: {e}")
        return False
