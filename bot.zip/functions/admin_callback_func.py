from aiogram.types import CallbackQuery
from aiogram import Bot
import logging
# Import the function to start adding
from admin.down_expenses import download_expenses_command
from admin.down_orders import download_orders_command
from admin.down_users import download_users_command
from admin.down_storage import download_products_command
from keyboards.admin_inlinekeys import admin_menu_keyboard

# Define constants for callback data
ADMIN_MENU_CALLBACK = "admin_menu"
DOWN_STORAGE_CALLBACK = "down_storage"
DOWN_USERS_CALLBACK = "down_users"
DOWN_ORDERS_CALLBACK = "down_orders"
DOWN_EXPENSES_CALLBACK = "down_expenses"

async def admin_handle_callback(callback_query: CallbackQuery, bot: Bot):
    await bot.answer_callback_query(callback_query.id)

    user_id = callback_query.from_user.id  # Get the user ID from the callback

    try:
        if callback_query.data == ADMIN_MENU_CALLBACK:
            keyboard = admin_menu_keyboard()
            await bot.send_message(user_id, "Admin Menu:", reply_markup=keyboard)
            logging.info(f"Admin menu requested by user {user_id}")

        elif callback_query.data == DOWN_STORAGE_CALLBACK:
            await bot.send_message(user_id, "📦 Downloading STORAGE data, please wait...")  # Specify user_id and text
            await download_products_command(callback_query.message, user_id)  # Pass user_id explicitly
            logging.info(f"Admin menu Download storage process initiated by user {user_id}")
        
        elif callback_query.data == DOWN_USERS_CALLBACK:
            await bot.send_message(user_id, "👥 Downloading USERS data, please wait...")  # Specify user_id and text
            await download_users_command(callback_query.message, user_id)  # Pass user_id explicitly
            logging.info(f"Admin menu Download storage process initiated by user {user_id}")
        
        elif callback_query.data == DOWN_ORDERS_CALLBACK:
            await bot.send_message(user_id, "🛒 Downloading ORDERS data, please wait...")  # Specify user_id and text
            await download_orders_command(callback_query.message, user_id)  # Pass user_id explicitly
            logging.info(f"Admin menu Download storage process initiated by user {user_id}")
        
        elif callback_query.data == DOWN_EXPENSES_CALLBACK:
            await bot.send_message(user_id, "🧾 Downloading EXPENSES data, please wait...")  # Specify user_id and text
            await download_expenses_command(callback_query.message, user_id)  # Pass user_id explicitly
            logging.info(f"Admin menu Download storage process initiated by user {user_id}")

        else:
            logging.warning(f"Unknown callback data received Admin menu: {callback_query.data} from user {user_id}")
            await bot.send_message(user_id, "❌ Unknown option selected. Please try again.")
    
    except Exception as e:
        logging.error(f"Failed to process callback: {callback_query.data}. Error: {e}", exc_info=True)
        await bot.send_message(user_id, "❌ An error occurred while processing your request Admin menu.")

