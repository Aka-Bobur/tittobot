import aiosqlite, logging

async def connect_to_db():
    return await aiosqlite.connect('database.db')

async def is_user_admin(user_id: int) -> bool:
    print(f"Checking admin status for user ID: {user_id}")  # Print the user ID being checked
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT admin FROM users WHERE telegram_user_id = ?", (user_id,)) as cursor:
            result = await cursor.fetchone()
            print(f"Fetched result for user {user_id}: {result}")  # Log the fetched result
        await conn.close()
        if result:
            is_admin = result[0].lower() == 'true'
            logging.debug(f"User {user_id} admin status: {is_admin}")
            return is_admin
        else:
            logging.debug(f"User {user_id} not found in database.")
            return False
    except aiosqlite.Error as e:
        logging.error(f"Database error while checking admin status for user {user_id}: {e}")
        return False
    except Exception as e:
        logging.error(f"Unexpected error while checking admin status for user {user_id}: {e}")
        return False
