from aiogram.types import Message
from aiogram import Bot

async def help_command_answer(message: Message, bot: Bot):
    help_text = """ Bot buyruqlari:
    /admin - admin menyusi
    /sotuvchi - sotuvchi menyusi
    """
    await message.answer(help_text)

async def admin_command_answer(message: Message, bot: Bot):
    admin_text = """ admin buyruqlari:
    /new_product - yangi mahsulot qo'shish
    /view_products - mahsulotlarni ko'rish
    /add_order - 
    """
    await message.answer(admin_text)

async def seller_command_answer(message: Message, bot: Bot):
    seller_text = """ sotuvchi buyruqlari:
    /new_product - yangi mahsulot qo'shish
    /view_products - mahsulotlarni ko'rish
    /add_order - 
    """
    await message.answer(seller_text)