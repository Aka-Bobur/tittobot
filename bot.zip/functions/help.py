from aiogram.types import Message
from aiogram import Bot

from keyboards.admin_inlinekeys import admin_menu_keyboard, seller_menu_keyboard
from functions.admin_database import is_user_admin
from functions.seller_database import is_user_admin_or_seller

async def help_command_answer(message: Message, bot: Bot):
    help_text = """ Bot buyruqlari:
    /admin - admin menyusi
    /sotuvchi - sotuvchi menyusi
    """
    await message.answer(help_text)

async def admin_command_answer(message: Message, bot: Bot):
    user_id = message.from_user.id
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("Sizda ushbu buyruqni ishlatish uchun ruxsat yo'q.")
        return
    keyboard = admin_menu_keyboard()
    admin_text = """ admin buyruqlari:
    /view_products - mahsulotlarni ko'rish
    """
    await message.answer(admin_text, reply_markup=keyboard)

async def seller_command_answer(message: Message, bot: Bot):
    user_id = message.from_user.id
    is_admin_or_seller = await is_user_admin_or_seller(user_id)
    if not is_admin_or_seller:
        await message.answer("Sizda ushbu buyruqni ishlatish uchun ruxsat yo'q.")
        return
    keyboard = seller_menu_keyboard()
    seller_text = """ sotuvchi buyruqlari:
    /view_products - mahsulotlarni ko'rish
    """
    await message.answer(seller_text, reply_markup=keyboard)