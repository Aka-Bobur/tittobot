from aiogram.types import CallbackQuery
from aiogram import Bot
import logging
from aiogram.fsm.context import FSMContext

from admin.delete_expense import initiate_delete_expense
from count.expense import initiate_add_expense

# Define constants for callback data
ADD_EXPENSE_CALLBACK = "add_expense"
DELETE_EXPENSE_CALLBACK = "delete_expense"

async def expense_handle_callback(callback_query: CallbackQuery, bot: Bot, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)

    # Check the current state
    current_state = await state.get_state()
    logging.info(f"Current state: {current_state} for user {callback_query.from_user.id}")

    user_id = callback_query.from_user.id  # Get the correct user ID directly from the callback query

    try:
        
        if callback_query.data == ADD_EXPENSE_CALLBACK:
            await initiate_add_expense(callback_query.message, state, user_id)  # Pass user_id explicitly
            logging.warning(f"Add Expense process initiated by user {user_id}")

        elif callback_query.data == DELETE_EXPENSE_CALLBACK:
            await initiate_delete_expense(callback_query.message, state, user_id)  # Pass user_id explicitly
            logging.warning(f"Delete Expense process initiated by user {user_id}")

        else:
            logging.warning(f"Unknown Expense callback data received: {callback_query.data} from user {user_id}")
            await bot.send_message(user_id, "❌ Unknown option selected in Expense callback. Please try again.")
    
    except Exception as e:
        logging.error(f"Failed to process callback Expense: {callback_query.data}. Error: {e}", exc_info=True)
        await bot.send_message(user_id, "❌ An error occurred while processing your request Expense callback.")
