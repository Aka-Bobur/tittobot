from aiogram.types import CallbackQuery
from aiogram import Bot
import logging
from admin.new_user import finalize_new_admin, initiate_new_admin, process_admin_status, process_seller_status  # Import the function to start adding a new admin
from aiogram.fsm.context import FSMContext

# Define constants for callback data
NEW_ADMIN_CALLBACK = "new_user"

async def start_handle_callback(callback_query: CallbackQuery, bot: Bot, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)

    # Check the current state
    current_state = await state.get_state()
    logging.info(f"Current state: {current_state} for user {callback_query.from_user.id}")

    user_id = callback_query.from_user.id  # Get the correct user ID directly from the callback query

    try:
        
        if callback_query.data == NEW_ADMIN_CALLBACK:
            await initiate_new_admin(callback_query.message, state, user_id)  # Pass user_id explicitly
            logging.info(f"New admin process initiated by user {user_id}")
        
        elif callback_query.data.startswith("role_"):  # Handle role selection
            role = callback_query.data.split('_')[1]
            await state.update_data(roles=role)  # Save the selected role in the state
            await bot.send_message(user_id, f"Role selected: {role.capitalize()}")
            logging.info(f"Role '{role}' selected for user {user_id}")
            # Now proceed to the admin status selection
            await state.set_state('waiting_for_admin')
            await process_admin_status(callback_query.message, state)  # Display the admin status keyboard
        
        elif callback_query.data.startswith("admin_"):  # Handle admin status selection
            admin_status = callback_query.data.split('_')[1]
            await state.update_data(admin=admin_status)  # Save admin status in the state
            await bot.send_message(user_id, f"Admin status selected: {admin_status.capitalize()}")
            logging.info(f"Admin status '{admin_status}' selected for user {user_id}")
            # Now proceed to the seller status selection
            await state.set_state('waiting_for_seller')
            await process_seller_status(callback_query.message, state)
        
        elif callback_query.data.startswith("seller_"):  # Handle seller status selection
            seller_status = callback_query.data.split('_')[1]
            await state.update_data(seller=seller_status)  # Save seller status in the state
            await bot.send_message(user_id, f"Seller status selected: {seller_status.capitalize()}")
            logging.info(f"Seller status '{seller_status}' selected for user {user_id}")
            # Now finalize the new admin process
            await finalize_new_admin(callback_query, state)
        
        else:
            logging.warning(f"Unknown newuser callback data received: {callback_query.data} from user {user_id}")
            await bot.send_message(user_id, "❌ Unknown option selected. Please try again.")
    
    except Exception as e:
        logging.error(f"Failed to process callback newuser: {callback_query.data}. Error: {e}", exc_info=True)
        await bot.send_message(user_id, "❌ An error occurred while processing your request newuser.")
