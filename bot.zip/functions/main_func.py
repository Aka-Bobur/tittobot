from aiogram.types import Message
from aiogram import Bot
import aiosqlite
from datetime import datetime
from keyboards.admin_inlinekeys import admin_menu_keyboard  # Import the keyboard function

async def connect_to_db():
    return await aiosqlite.connect('database.db')

async def start_bot(bot: Bot):
    await bot.send_message(chat_id=632862318, text="✅ Bot ishni boshladi")
    print("Bot started")

async def shutdown_bot(bot: Bot):
    await bot.send_message(chat_id=632862318, text="🛑 Bot ishni tugatdi")

async def start_command_answer(message: Message, bot: Bot):
    user_id = message.from_user.id
    username = message.from_user.username or "foydalanuvchi"

    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT admin, seller, roles FROM users WHERE telegram_user_id = ?", (user_id,)) as cursor:
            result = await cursor.fetchone()
            

        if result:
            is_admin = result[0] == 'true'
            is_seller = result[1] == 'true'

            if is_admin:
                keyboard = admin_menu_keyboard()
                await message.answer(
                    "Siz adminsiz. Administrator menyusi uchun /admin buyrug'ini kiriting.",
                    reply_markup=keyboard
                )
            elif is_seller:
                await message.answer("Siz sotuvchisiz.")
            else:
                food_menu_message = (
                    f"<b>Salom, {username}!</b>\n"
                    f"Siz oddiy foydalanuvchi sifatida ro'yxatdan o'tgansiz.\n"
                    f"Bu bot faqat TITTO admini va sotuvchilari uchun. "
                    f"Sizni quyidagi botga yo'naltiramiz: <a href='https://telegra.ph/Menyu-Moto-Food-07-01'>Menu</a>"
                )
                await message.answer(food_menu_message, parse_mode="HTML")
        else:
            user_date = datetime.now().strftime('%d.%m.%Y %H:%M')
            await conn.execute(
                "INSERT INTO users (telegram_user_id, telegram_username, roles, admin, seller, datetime) VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, username, 'user', 'false', 'false', user_date)
            )
            await conn.commit()
            welcome_message = (
                f"<b>Xush kelibsiz, {username}!</b>\n"
                f"Siz oddiy foydalanuvchi sifatida ro'yxatdan o'tdingiz.\n"
                f"Bu bot faqat TITTO admini va sotuvchilari uchun. "
                f"Sizni quyidagi botga yo'naltiramiz: <a href='https://telegra.ph/Menyu-Moto-Food-07-01'>Menu</a>"
            )
            await message.answer(welcome_message, parse_mode="HTML")

        await conn.close()

    except aiosqlite.Error as e:
        await message.reply(f"Database error: {e}")
