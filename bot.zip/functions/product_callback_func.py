from aiogram.types import CallbackQuery
from aiogram import Bot
import logging
from admin.delete_product import initiate_delete_product
from aiogram.fsm.context import FSMContext

# Define constants for callback data
DELETE_PRODUCT_CALLBACK = "delete_product"

async def product_handle_callback(callback_query: CallbackQuery, bot: Bot, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)

    # Check the current state
    current_state = await state.get_state()
    logging.info(f"Current state: {current_state} for user {callback_query.from_user.id}")

    user_id = callback_query.from_user.id  # Get the correct user ID directly from the callback query

    try:
        
        if callback_query.data == DELETE_PRODUCT_CALLBACK:
            await initiate_delete_product(callback_query.message, state, user_id)  # Pass user_id explicitly
            logging.warning(f"Delete user process initiated by user {user_id}")

        else:
            logging.warning(f"Unknown product callback data received: {callback_query.data} from user {user_id}")
            await bot.send_message(user_id, "❌ Unknown option selected. Please try again.")
    
    except Exception as e:
        logging.error(f"Failed to process callback product: {callback_query.data}. Error: {e}", exc_info=True)
        await bot.send_message(user_id, "❌ An error occurred while processing your request product.")
