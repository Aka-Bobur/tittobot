from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def admin_menu_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="New User", callback_data="new_user")],
        [InlineKeyboardButton(text="Admin Menu", callback_data="admin_menu")]
    ])

def role_selection_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Admin", callback_data="role_admin")],
        [InlineKeyboardButton(text="Seller", callback_data="role_seller")]
    ])

def admin_status_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="true", callback_data="admin_true")],
        [InlineKeyboardButton(text="false", callback_data="admin_false")]
    ])

def seller_status_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="true", callback_data="seller_true")],
        [InlineKeyboardButton(text="false", callback_data="seller_false")]
    ])
