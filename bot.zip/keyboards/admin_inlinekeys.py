from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def admin_menu_keyboard():
    """
    Creates an inline keyboard for the admin menu.

    Returns:
        InlineKeyboardMarkup: The keyboard markup with buttons for administrative actions.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="New User", callback_data="new_user")],
        [InlineKeyboardButton(text="Delete User", callback_data="delete_user")],
        [InlineKeyboardButton(text="Delete Product", callback_data="delete_product")],
        [InlineKeyboardButton(text="Download Storage", callback_data="down_storage")],
        [InlineKeyboardButton(text="Download Users", callback_data="down_users")],
        [InlineKeyboardButton(text="Download Orders", callback_data="down_orders")],
        [InlineKeyboardButton(text="Download Expenses", callback_data="down_expenses")]
    ])
