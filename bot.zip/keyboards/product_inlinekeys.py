from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def delete_product_confirmation_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Yes", callback_data="delete_confirm_yes")],
        [InlineKeyboardButton(text="No", callback_data="delete_confirm_no")]
    ])
