from aiogram.types import Message
import aiosqlite

# Database connection function
async def connect_to_db():
    return await aiosqlite.connect('database.db')

# Function to check if the user is either an admin or a seller
async def is_user_admin_or_seller(user_id: int) -> bool:
    try:
        conn = await connect_to_db()
        async with conn.execute(
            "SELECT admin, seller FROM users WHERE telegram_user_id = ?", 
            (user_id,)
        ) as cursor:
            result = await cursor.fetchone()
        await conn.close()
        
        # Check if user is either an admin or a seller
        if result is not None:
            is_admin = result[0] == 'true'
            is_seller = result[1] == 'true'
            return is_admin or is_seller
        return False
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return False

# Function to get all products from the storage database
async def get_all_products() -> list:
    """Retrieve all products from the storage database."""
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT * FROM storage") as cursor:
            products = await cursor.fetchall()
        await conn.close()
        return products
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return []

# Command handler to view all products
async def view_products_command(message: Message):
    """Command handler for viewing all products."""
    user_id = message.from_user.id  
    if not await is_user_admin_or_seller(user_id):
        await message.answer("Sizda mahsulotlarni ko'rish uchun ruxsat yo'q.")
        return

    products = await get_all_products()
    if not products:
        await message.answer("Saqlash jadvalida mahsulot topilmadi.")
        return

    product_list = []  # To collect product information

    for product in products:
        product_id, product_name, product_cost, product_price, product_type = product[0], product[1], product[2], product[3], product[4]

        # Construct product info string
        product_info = (
            f"ID: {product_id}\n"
            f"Name: {product_name}\n"
            f"Cost: {product_cost}\n"
            f"Price: {product_price}\n"
            f"Type: {product_type}\n"
        )
        product_list.append(product_info)

    if product_list:
        await message.answer("Ombordagi mahsulotlar:\n" + "\n\n".join(product_list))
    else:
        await message.answer("Omborda hech qanday mahsulot topilmadi.")
