from aiogram.types import Message
from aiogram import Dispatcher
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import aiosqlite
from datetime import datetime
import pytz
import random
from functions.seller_database import is_user_admin_or_seller, connect_to_db

# Define states for adding an order
class AddOrderStates(StatesGroup):
    waiting_for_product_id = State()
    waiting_for_quantity = State()


async def get_product_by_id(product_id: int):
    """Retrieve product details from the storage by product_id."""
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT product_name, product_price, product_cost FROM storage WHERE product_id = ?", (product_id,)) as cursor:
            product = await cursor.fetchone()
        await conn.close()
        return product  # Returns None if no product is found
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return None

async def add_order_to_db(order_id, order_date, user_id, product_id, product_name, product_price, product_cost, sold_quantity, total_price, total_cost, total_profit):
    """Add a new order to the orders table."""
    try:
        conn = await connect_to_db()
        # Get the current date and time without fractional seconds
        local_tz = pytz.timezone("Asia/Tashkent")
        order_date = datetime.now(local_tz).strftime('%d.%m.%Y %H:%M')

        await conn.execute(
            """INSERT INTO orders
            (order_id, order_date, user_id, product_id, product_name, product_price, product_cost, sold_quantity, total_price, total_cost, total_profit) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (order_id, order_date, user_id, product_id, product_name, product_price, product_cost, sold_quantity, total_price, total_cost, total_profit)
        )
        await conn.commit()
        await conn.close()
    except aiosqlite.Error as e:
        await conn.close()
        raise Exception(f"Failed to insert order: {e}")

async def initiate_add_order(message: Message, state: FSMContext, user_id: int) -> None:
    """Initiate the process of adding a new order."""
    is_admin = await is_user_admin_or_seller(user_id)
    if not is_admin:
        await message.answer("You do not have permission to add orders.")
        return

    await message.answer("Please provide the product ID:")
    await state.set_state(AddOrderStates.waiting_for_product_id)

async def process_order_product_id(message: Message, state: FSMContext):
    """Process the product ID provided by the user."""
    try:
        product_id = int(message.text.strip())
        product = await get_product_by_id(product_id)

        if product is None:
            await message.answer("Invalid product ID. Please try again.")
            return

        await state.update_data(product_id=product_id, product=product)
        await message.answer(f"Product '{product[0]}' selected. Please provide the quantity sold:")
        await state.set_state(AddOrderStates.waiting_for_quantity)
    except ValueError:
        await message.answer("Invalid product ID. Please enter a valid number")

async def is_order_id_unique(order_id: int) -> bool:
    """Check if the order_id exists in the orders table."""
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT 1 FROM orders WHERE order_id = ?", (order_id,)) as cursor:
            result = await cursor.fetchone()
        await conn.close()
        return result is None  # True if order_id is not found
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return False

async def generate_unique_order_id() -> int:
    """Generate a unique order_id that does not exist in the database."""
    while True:
        order_id = random.randint(1000, 99999)  # Generate a random 5-digit number
        if await is_order_id_unique(order_id):  # Check if it's unique
            return order_id  # Return the ID if it's unique

async def process_order_quantity(message: Message, state: FSMContext):
    """Process the quantity provided by the user and complete the order."""
    try:
        sold_quantity = int(message.text.strip())
        data = await state.get_data()
        product_id = data.get('product_id')
        product_name, product_price, product_cost = data.get('product')

        # Calculate total price, total cost, and profit
        total_price = sold_quantity * product_price
        total_cost = sold_quantity * product_cost
        total_profit = total_price - total_cost

        # Prepare the order details
        order_id = await generate_unique_order_id()  # Generate a unique order_id
        order_date = datetime.now() 
        user_id = message.from_user.id

        # Insert the order into the database
        try:
            await add_order_to_db(order_id, order_date, user_id, product_id, product_name, product_price, product_cost, sold_quantity, total_price, total_cost, total_profit)
            await message.answer(f"Order for {sold_quantity} units of '{product_name}' added successfully!")
        except Exception as e:
            await message.answer(str(e))

        await state.clear()
    except ValueError:
        await message.answer("Invalid quantity. Please enter a valid number.")

def register_order_handlers(dp: Dispatcher):
    """Register all order-related handlers."""
    dp.message.register(process_order_product_id, AddOrderStates.waiting_for_product_id)
    dp.message.register(process_order_quantity, AddOrderStates.waiting_for_quantity)
