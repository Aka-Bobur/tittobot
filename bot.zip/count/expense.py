from aiogram.types import Message
from aiogram import Dispatcher
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import aiosqlite
from datetime import datetime
import random

# Define states for adding an expense
class AddExpenseStates(StatesGroup):
    waiting_for_expense_name = State()
    waiting_for_expense_amount = State()
    waiting_for_expense_type = State()

async def connect_to_db():
    return await aiosqlite.connect('database.db')

async def is_user_admin_or_seller(user_id: int) -> bool:
    """Check if the user is an admin or seller."""
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT admin, seller FROM users WHERE telegram_user_id = ?", (user_id,)) as cursor:
            result = await cursor.fetchone()
        await conn.close()

        return result is not None and (result[0] == 'true' or result[1] == 'true')  # True if admin or seller
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return False

async def add_expense_to_db(expense_id, expense_date, user_id, expense_name, expense_amount, expense_type):
    """Add a new expense to the expenses table."""
    try:
        conn = await connect_to_db()

        # Get the current date and time without fractional seconds
        expense_date = datetime.now().strftime('%d.%m.%Y %H:%M')

        await conn.execute(
            """INSERT INTO expenses
            (expense_id, expense_date, user_id, expense_name, expense_amount, expense_type) 
            VALUES (?, ?, ?, ?, ?, ?)""",
            (expense_id, expense_date, user_id, expense_name, expense_amount, expense_type)
        )
        await conn.commit()
        await conn.close()
    except aiosqlite.Error as e:
        await conn.close()
        raise Exception(f"Failed to insert expense: {e}")

async def generate_unique_expense_id() -> int:
    """Generate a unique expense_id that does not exist in the database."""
    while True:
        expense_id = random.randint(1000, 99999)  # Generate a random 5-digit number
        if await is_expense_id_unique(expense_id):  # Check if it's unique
            return expense_id  # Return the ID if it's unique

async def is_expense_id_unique(expense_id: int) -> bool:
    """Check if the expense_id exists in the expenses table."""
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT 1 FROM expenses WHERE expense_id = ?", (expense_id,)) as cursor:
            result = await cursor.fetchone()
        await conn.close()
        return result is None  # True if expense_id is not found
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return False

async def initiate_add_expense(message: Message, state: FSMContext):
    """Initiate the process of adding a new expense."""
    user_id = message.from_user.id
    if not await is_user_admin_or_seller(user_id):
        await message.answer("You do not have permission to add expenses.")
        return

    await message.answer("Please provide the expense name:")
    await state.set_state(AddExpenseStates.waiting_for_expense_name)

async def process_expense_name(message: Message, state: FSMContext):
    """Process the expense name provided by the user."""
    expense_name = message.text.strip()
    await state.update_data(expense_name=expense_name)
    await message.answer("Please provide the expense amount:")
    await state.set_state(AddExpenseStates.waiting_for_expense_amount)

async def process_expense_amount(message: Message, state: FSMContext):
    """Process the expense amount provided by the user."""
    try:
        expense_amount = float(message.text.strip())
        await state.update_data(expense_amount=expense_amount)
        await message.answer("Please provide the expense type (e.g., 'electr', 'utils', 'transport', 'other'):")
        await state.set_state(AddExpenseStates.waiting_for_expense_type)
    except ValueError:
        await message.answer("Invalid amount. Please enter a valid number.")

async def process_expense_type(message: Message, state: FSMContext):
    """Process the expense type provided by the user and save it to the database."""
    expense_type = message.text.strip().lower()

    # Validate expense type
    if expense_type not in ["electr", "utils", "transport", "other"]:
        await message.answer("Invalid expense type. Please enter either 'electr', 'utils', 'transport', or 'other':")
        return
    await state.update_data(expense_type=expense_type)
    data = await state.get_data()

    # Gather all data collected from previous states
    expense_name = data.get('expense_name')
    expense_amount = data.get('expense_amount')
    expense_type = data.get('expense_type')

    try:
        # Generate a unique expense ID
        expense_id = await generate_unique_expense_id()
        expense_date = datetime.now()  # Capture the current date
        user_id = message.from_user.id

        # Insert the expense into the database
        await add_expense_to_db(expense_id, expense_date, user_id, expense_name, expense_amount, expense_type)
        await message.reply(f"Expense '{expense_name}' added successfully!")
    except Exception as e:
        await message.answer(str(e))  # Send error message to user

    await state.clear()  # Clear the FSM state after completing the process

# Command handler for adding an expense
async def add_expense_command(message: Message, state: FSMContext):
    """Command handler to start adding an expense."""
    await initiate_add_expense(message, state)

def register_expense_handlers(dp: Dispatcher):
    """Register all expense-related handlers."""
    dp.message.register(process_expense_name, AddExpenseStates.waiting_for_expense_name)
    dp.message.register(process_expense_amount, AddExpenseStates.waiting_for_expense_amount)
    dp.message.register(process_expense_type, AddExpenseStates.waiting_for_expense_type)
