from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram import Dispatcher
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
import aiosqlite
from datetime import datetime
import pytz

import random
from functions.seller_database import is_user_admin_or_seller, connect_to_db

# Define states for adding an expense
class AddExpenseStates(StatesGroup):
    waiting_for_electr_kw = State()
    waiting_for_electr_type = State()
    waiting_for_water_litr = State()
    waiting_for_other_expense_confirmation = State()  # State for confirming other expense
    waiting_for_expense_other = State()
    waiting_for_expense_other_amount = State()
    waiting_for_expense_other_cost = State()  # New state to ask for other expense cost

async def generate_unique_expense_id() -> int:
    """Generate a unique expense_id that does not exist in the database."""
    while True:
        expense_id = random.randint(1000, 99999)  # Generate a random 5-digit number
        if await is_expense_id_unique(expense_id):  # Check if it's unique
            return expense_id  # Return the ID if it's unique

async def is_expense_id_unique(expense_id: int) -> bool:
    """Check if the expense_id exists in the expenses table."""
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT 1 FROM expenses WHERE expense_id = ?", (expense_id,)) as cursor:
            result = await cursor.fetchone()
        await conn.close()
        return result is None  # True if expense_id is not found
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return False

async def add_expense_to_db(expense_id, expense_date, user_id, elektr_kw, expense_elektr450, expense_elektr900, water_litr, expense_water, expense_rent, expense_tax, expense_other, expense_other_amount, expense_other_cost, total_expenses):
    """Add a new expense to the expenses table."""
    try:
        conn = await connect_to_db()
        await conn.execute(
            """INSERT INTO expenses 
            (expense_id, expense_date, user_id, elektr_kw, expense_elektr450, expense_elektr900, water_litr, expense_water, expense_rent, expense_tax, expense_other, expense_other_amount, expense_other_cost, total_expenses)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (expense_id, expense_date, user_id, elektr_kw, expense_elektr450, expense_elektr900, water_litr, expense_water, expense_rent, expense_tax, expense_other, expense_other_amount, expense_other_cost, total_expenses)
        )
        await conn.commit()
        await conn.close()
    except aiosqlite.Error as e:
        await conn.close()
        raise Exception(f"Failed to insert expense: {e}")

async def initiate_add_expense(message: Message, state: FSMContext, user_id: int) -> None:
    """Initiate the process of adding a new expense."""
    is_admin = await is_user_admin_or_seller(user_id)
    if not is_admin:
        await message.answer("You do not have permission to add expenses.")
        return

    await message.answer("Please provide the electricity usage in kilowatts (kw):")
    await state.set_state(AddExpenseStates.waiting_for_electr_kw)

async def process_electr_kw(message: Message, state: FSMContext):
    """Process the electricity kw provided by the user."""
    try:
        elektr_kw = int(message.text.strip())
        await state.update_data(elektr_kw=elektr_kw)

        # Send inline keyboard for selecting electricity type (electr450 or electr900)
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="450", callback_data="electr450"),
            InlineKeyboardButton(text="900", callback_data="electr900")]
        ])
        await message.answer("Please select the electricity type:", reply_markup=keyboard)
        await state.set_state(AddExpenseStates.waiting_for_electr_type)
    except ValueError:
        await message.answer("Invalid value. Please enter a valid number for kilowatts.")

async def process_electr_type(callback_query: CallbackQuery, state: FSMContext):
    """Process the electricity type selected by the user."""
    type_selected = callback_query.data
    data = await state.get_data()
    elektr_kw = data.get('elektr_kw')

    # Connect to the database
    conn = await connect_to_db()

    try:
        if type_selected == 'electr450':
            async with conn.execute("SELECT cons_amount FROM cons_expense WHERE cons_name = 'electr450'") as cursor:
                row = await cursor.fetchone()
                expense_elektr450 = row[0] * elektr_kw  # Adjusting the cost based on the electricity used
            expense_elektr900 = 0

        elif type_selected == 'electr900':
            async with conn.execute("SELECT cons_amount FROM cons_expense WHERE cons_name = 'electr900'") as cursor:
                row = await cursor.fetchone()
                expense_elektr900 = row[0] * elektr_kw  # Adjusting the cost based on the electricity used
            expense_elektr450 = 0

        else:
            await callback_query.message.answer("Invalid selection. Please choose again.")
            return

        await conn.close()

        # Update state data
        await state.update_data(expense_elektr450=expense_elektr450, expense_elektr900=expense_elektr900)

        # Ask for water liters
        await callback_query.message.answer("Please provide the water liters used:")
        await state.set_state(AddExpenseStates.waiting_for_water_litr)

    except aiosqlite.Error as e:
        await conn.close()
        await callback_query.message.answer(f"Database error: {e}")

async def process_water_litr(message: Message, state: FSMContext):
    """Process water liters and calculate the water expense."""
    try:
        water_litr = int(message.text.strip())
        conn = await connect_to_db()

        async with conn.execute("SELECT cons_amount FROM cons_expense WHERE cons_name = 'water'") as cursor:
            row = await cursor.fetchone()
            expense_water = row[0] * water_litr  # Calculate the water expense

        await conn.close()

        # Update state with water liters and water expense
        await state.update_data(water_litr=water_litr, expense_water=expense_water)

        # Ask if the user wants to add other expenses
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Yes", callback_data="add_other_expense"),
            InlineKeyboardButton(text="No", callback_data="no_other_expense")]
        ])
        await message.answer("Do you want to add another expense?", reply_markup=keyboard)
        await state.set_state(AddExpenseStates.waiting_for_other_expense_confirmation)

    except ValueError:
        await message.answer("Invalid value. Please enter a valid number for water liters.")
    except aiosqlite.Error as e:
        await message.answer(f"Database error: {e}")

async def process_other_expense_confirmation(callback_query: CallbackQuery, state: FSMContext):
    """Process the confirmation for adding other expenses."""
    if callback_query.data == "add_other_expense":
        await callback_query.message.answer("Please provide the other expense name (e.g., gas, tools):")
        await state.set_state(AddExpenseStates.waiting_for_expense_other)
    else:
        user_id = callback_query.from_user.id
        await finalize_expense(callback_query.message, state, user_id=user_id)

async def process_expense_other(message: Message, state: FSMContext):
    """Process the other expense name provided by the user."""
    other_expense_name = message.text.strip()
    await state.update_data(expense_other=other_expense_name)

    await message.answer("Please provide the amount for the other expense:")
    await state.set_state(AddExpenseStates.waiting_for_expense_other_amount)

async def process_expense_other_amount(message: Message, state: FSMContext):
    """Process the amount for the other expense."""
    try:
        other_expense_amount = int(message.text.strip())
        await state.update_data(expense_other_amount=other_expense_amount)

        await message.answer("Please provide the cost for the other expense:")
        await state.set_state(AddExpenseStates.waiting_for_expense_other_cost)

    except ValueError:
        await message.answer("Invalid input. Please enter a valid number for the other expense amount.")

async def process_expense_other_cost(message: Message, state: FSMContext):
    """Process the cost for the other expense."""
    try:
        other_expense_cost = int(message.text.strip())
        await state.update_data(expense_other_cost=other_expense_cost)

        # Finalize the expense entry now that all details are collected
        await finalize_expense(message, state)

    except ValueError:
        await message.answer("Invalid input. Please enter a valid number for the other expense cost.")

async def finalize_expense(message: Message, state: FSMContext, user_id):
    """Finalize the expense entry."""
    data = await state.get_data()
    expense_id = await generate_unique_expense_id()
    local_tz = pytz.timezone("Asia/Tashkent")
    expense_date = datetime.now(local_tz).strftime('%d.%m.%Y %H:%M')
    user_id = user_id
    elektr_kw = data.get('elektr_kw', 0)
    expense_elektr450 = data.get('expense_elektr450')
    expense_elektr900 = data.get('expense_elektr900')
    water_litr = data.get('water_litr', 0)
    expense_water = data.get('expense_water')
    expense_other = data.get('expense_other')
    expense_other_amount = data.get('expense_other_amount', 0)
    expense_other_cost = data.get('expense_other_cost', 0)
    
    # Fetch rent and tax from cons_expense
    conn = await connect_to_db()
    async with conn.execute("SELECT cons_amount FROM cons_expense WHERE cons_name = 'rent'") as cursor:
        rent_row = await cursor.fetchone()
        expense_rent = rent_row[0]

    async with conn.execute("SELECT cons_amount FROM cons_expense WHERE cons_name = 'tax'") as cursor:
        tax_row = await cursor.fetchone()
        expense_tax = tax_row[0]

    await conn.close()

    total_expenses = sum(filter(None, [
        expense_elektr450, expense_elektr900, expense_water,
        expense_rent, expense_tax, expense_other_cost
    ]))

    try:
        # Add the new expense to the database
        await add_expense_to_db(
            expense_id=expense_id, expense_date=expense_date, user_id=user_id,
            elektr_kw=elektr_kw, expense_elektr450=expense_elektr450, expense_elektr900=expense_elektr900,
            water_litr=water_litr, expense_water=expense_water, expense_rent=expense_rent,
            expense_tax=expense_tax, expense_other=expense_other, expense_other_amount=expense_other_amount,
            expense_other_cost=expense_other_cost, total_expenses=total_expenses
        )

        await message.answer(f"Expense {expense_id} added successfully.")
    except Exception as e:
        await message.answer(f"Failed to add expense: {e}")

    await state.clear()  # Reset the state after completion

def add_expense_handlers(dp: Dispatcher):
    """Register handlers for adding expenses."""
    dp.message.register(process_electr_kw, StateFilter(AddExpenseStates.waiting_for_electr_kw))
    dp.callback_query.register(process_electr_type, StateFilter(AddExpenseStates.waiting_for_electr_type))
    dp.message.register(process_water_litr, StateFilter(AddExpenseStates.waiting_for_water_litr))
    dp.callback_query.register(process_other_expense_confirmation, StateFilter(AddExpenseStates.waiting_for_other_expense_confirmation))
    dp.message.register(process_expense_other, StateFilter(AddExpenseStates.waiting_for_expense_other))
    dp.message.register(process_expense_other_amount, StateFilter(AddExpenseStates.waiting_for_expense_other_amount))
    dp.message.register(process_expense_other_cost, StateFilter(AddExpenseStates.waiting_for_expense_other_cost))
