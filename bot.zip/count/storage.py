from aiogram.types import Message
from aiogram import Dispatcher
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import aiosqlite

class AddProductStates(StatesGroup):
    waiting_for_product_id = State()
    waiting_for_product_name = State()
    waiting_for_product_cost = State()
    waiting_for_product_price = State()
    waiting_for_product_type = State()

async def connect_to_db():
    return await aiosqlite.connect('database.db')

async def is_user_admin(user_id: int) -> bool:
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT admin FROM users WHERE telegram_user_id = ?", (user_id,)) as cursor:
            result = await cursor.fetchone()
        await conn.close()
        return result is not None and result[0] == 'true'
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return False

async def add_product_to_storage(product_id, product_name, product_cost, product_price, product_type):
    """Add a new product to the storage database."""
    try:
        conn = await connect_to_db()  # Connect to the database
        await conn.execute(
            "INSERT INTO storage (product_id, product_name, product_cost, product_price, product_type) VALUES (?, ?, ?, ?, ?)",
            (product_id, product_name, product_cost, product_price, product_type)
        )
        await conn.commit()  # Commit the transaction
        await conn.close()   # Close the connection
    except aiosqlite.Error as e:
        await conn.close()  # Ensure the connection is closed on error
        raise Exception(f"Failed to insert product into storage: {e}")

async def initiate_add_product(message: Message, state: FSMContext):
    """Initiate the process of adding a new product."""
    user_id = message.from_user.id
    if not await is_user_admin(user_id):
        await message.answer("You do not have permission to add products.")
        return

    await message.answer("Please provide the product ID:")
    await state.set_state(AddProductStates.waiting_for_product_id)

async def process_product_id(message: Message, state: FSMContext):
    product_id = message.text.strip()
    await state.update_data(product_id=product_id)
    await message.answer("Please provide the product name:")
    await state.set_state(AddProductStates.waiting_for_product_name)

async def process_product_name(message: Message, state: FSMContext):
    product_name = message.text.strip()
    await state.update_data(product_name=product_name)
    await message.answer("Please provide the product cost:")
    await state.set_state(AddProductStates.waiting_for_product_cost)

async def process_product_cost(message: Message, state: FSMContext):
    try:
        product_cost = float(message.text.strip())
        await state.update_data(product_cost=product_cost)
        await message.answer("Please provide the product price:")
        await state.set_state(AddProductStates.waiting_for_product_price)
    except ValueError:
        await message.answer("Invalid cost. Please enter a valid number:")

async def process_product_price(message: Message, state: FSMContext):
    """Process the product price provided by the admin."""
    try:
        product_price = float(message.text.strip())
        await state.update_data(product_price=product_price)
        await message.reply("Please provide the product type (food/drink):")
        await state.set_state(AddProductStates.waiting_for_product_type)
    except ValueError:
        await message.answer("Invalid price. Please enter a valid number:")

async def process_product_type(message: Message, state: FSMContext):
    """Process the product type provided by the admin and save it to the database."""
    product_type = message.text.strip().lower()

    # Validate product type
    if product_type not in ["food", "drink"]:
        await message.answer("Invalid product type. Please enter either 'food' or 'drink':")
        return  # Return early to allow re-entry of product type

    data = await state.get_data()

    # Gather all data collected from previous states
    product_id = data.get('product_id')
    product_name = data.get('product_name')
    product_cost = data.get('product_cost')
    product_price = data.get('product_price')

    try:
        await add_product_to_storage(
            product_id,
            product_name,
            product_cost,
            product_price,
            product_type
        )
        await message.reply(f"Product '{product_name}' has been added to storage successfully.")
    except Exception as e:
        await message.answer(str(e))  # Send error message to user

    await state.clear()  # Clear the FSM state after completing the process


async def add_product_command(message: Message, state: FSMContext):
    """Command handler to start adding a product."""
    await initiate_add_product(message, state)

def register_add_product_handlers(dp: Dispatcher):
    dp.message.register(process_product_id, AddProductStates.waiting_for_product_id)
    dp.message.register(process_product_name, AddProductStates.waiting_for_product_name)
    dp.message.register(process_product_cost, AddProductStates.waiting_for_product_cost)
    dp.message.register(process_product_price, AddProductStates.waiting_for_product_price)
    dp.message.register(process_product_type, AddProductStates.waiting_for_product_type)
