import aiosqlite
import logging
from datetime import datetime
from aiogram import Dispatcher
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from functions.admin_database import is_user_admin, connect_to_db
from keyboards.newuser_inlinekeys import role_selection_keyboard, admin_status_keyboard, seller_status_keyboard

class NewAdminStates(StatesGroup):
    waiting_for_user_id = State()
    waiting_for_username = State()
    waiting_for_roles = State()
    waiting_for_admin = State()
    waiting_for_seller = State()

async def initiate_new_admin(message: Message, state: FSMContext, user_id: int) -> None:
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("You do not have permission to add a user.")
        return
    
    await message.answer("Please provide the Telegram user ID of the new admin:")
    await state.set_state(NewAdminStates.waiting_for_user_id)

async def process_user_id(message: Message, state: FSMContext) -> None:
    user_id = message.text.strip()
    
    if not user_id.isdigit():  # Basic validation for user ID
        await message.answer("Invalid user ID. Please enter a numeric value.")
        return
    
    await state.update_data(user_id=user_id)
    await message.answer("Please enter the username:")
    await state.set_state(NewAdminStates.waiting_for_username)

async def process_username(message: Message, state: FSMContext) -> None:
    username = message.text.strip()
    await state.update_data(username=username)
    await state.set_state(NewAdminStates.waiting_for_roles)
    keyboard = role_selection_keyboard()
    await message.answer("Please select user roles:", reply_markup=keyboard)

async def callback_role_selection(callback_query: CallbackQuery, state: FSMContext) -> None:
    role = callback_query.data.split('_')[1]
    await state.update_data(roles=role)
    await callback_query.message.edit_text(f"Selected role: {role.capitalize()}")
    logging.info(f"Role '{role}' selected. Transitioning to waiting_for_admin state.")
    # Proceed to admin status selection
    await process_admin_status(callback_query.message, state)
    await state.set_state(NewAdminStates.waiting_for_admin)

async def process_admin_status(message: Message, state: FSMContext) -> None:
    keyboard = admin_status_keyboard()
    await message.answer("Is this user an admin? (true/false):", reply_markup=keyboard)
    logging.info("Admin status selection presented.")

async def callback_admin_selection(callback_query: CallbackQuery, state: FSMContext) -> None:
    admin_status = callback_query.data.split('_')[1]
    await state.update_data(admin=admin_status)
    await callback_query.message.edit_text(f"Admin status: {admin_status.capitalize()}")
    logging.info(f"Admin status '{admin_status}' selected. Transitioning to waiting_for_seller state.")
    await process_seller_status(callback_query.message, state)
    await state.set_state(NewAdminStates.waiting_for_seller)

async def process_seller_status(message: Message, state: FSMContext) -> None:
    keyboard = seller_status_keyboard()
    await message.answer("Is this user a seller? (true/false):", reply_markup=keyboard)
    logging.info("Seller status selection presented.")

async def callback_seller_selection(callback_query: CallbackQuery, state: FSMContext) -> None:
    seller_status = callback_query.data.split('_')[1]
    await state.update_data(seller=seller_status)
    # Correcting the message access:
    await callback_query.message.edit_text(f"Seller status: {seller_status.capitalize()}")
    logging.info(f"Seller status '{seller_status}' selected. Transitioning to finalize_new_admin state.")
    
    await finalize_new_admin(callback_query, state)

async def finalize_new_admin(callback_query: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    telegram_user_id = data['user_id']
    telegram_username = data['username']
    roles = data['roles']
    admin = data['admin']
    seller = data['seller']

    try:
        conn = await connect_to_db()
        
        user_date = datetime.now().strftime('%d.%m.%Y %H:%M')  # Capture the current date
        async with conn.execute(
                "INSERT INTO users (telegram_user_id, telegram_username, roles, admin, seller, datetime) VALUES (?, ?, ?, ?, ?, ?)",
                (telegram_user_id, telegram_username, roles, admin, seller, user_date)
            ):
            await conn.commit()
        # Correcting the message access:
        await callback_query.message.answer(f"User {telegram_username} has been added as {roles}.")
    except aiosqlite.Error as e:
        await callback_query.message.answer(f"Failed to add user: {e}")
        await conn.close()
    await state.clear()

def new_user_register_handlers(dp: Dispatcher) -> None:
    dp.message.register(process_user_id, StateFilter(NewAdminStates.waiting_for_user_id))
    dp.message.register(process_username, StateFilter(NewAdminStates.waiting_for_username))
    dp.callback_query.register(callback_role_selection, lambda cb: cb.data.startswith("role_"))
    dp.callback_query.register(callback_admin_selection, lambda cb: cb.data.startswith("admin_"))
    dp.callback_query.register(callback_seller_selection, lambda cb: cb.data.startswith("seller_"))
