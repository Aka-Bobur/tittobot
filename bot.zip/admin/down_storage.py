import os
import time
from aiogram import types
from aiogram.types import Message
import aiosqlite
import xlsxwriter
from pathlib import Path
from functions.admin_database import is_user_admin, connect_to_db

# Get all products from the database
async def get_all_products() -> list:
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT * FROM storage") as cursor:
                products = await cursor.fetchall()
        await conn.close()
        return products
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return []

# Command handler to download products as an XLSX file
async def download_products_command(message: Message, user_id: int) -> None:
    """Command handler for downloading products as an XLSX file."""
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("Sizda mahsulotlarni yuklab olish uchun ruxsat yo'q.")
        return

    products = await get_all_products()
    if not products:
        await message.answer("Saqlash jadvalida mahsulot topilmadi.")
        return

    # Create 'data' directory if it doesn't exist
    data_folder = 'data'
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)

    # Generate XLSX file path inside the 'data' folder
    file_path = os.path.join(data_folder, 'products.xlsx')

    # Generate XLSX file with xlsxwriter
    with xlsxwriter.Workbook(file_path) as workbook:
        worksheet = workbook.add_worksheet()
        headers = ['ID', 'ProductID', 'Name', 'Cost', 'Price', 'Type']
        worksheet.write_row(0, 0, headers)

        for row_num, product in enumerate(products, start=1):
            worksheet.write_row(row_num, 0, product)

    # Use FSInputFile to send the file
    input_file = types.FSInputFile(file_path)  # Use FSInputFile with the file path
    # Create the caption with the current date
    caption = f"Mahsulotlar ro'yxati: {time.strftime('%d-%m-%Y', time.localtime())} sanasidagi"
    await message.answer_document(input_file, caption=caption)
    