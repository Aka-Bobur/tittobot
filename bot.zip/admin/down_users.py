import os
import time
from aiogram import types
from aiogram.types import Message
import aiosqlite
import xlsxwriter
from functions.admin_database import is_user_admin, connect_to_db

# Get all users from the database
async def get_all_users() -> list:
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT * FROM users") as cursor:
            users = await cursor.fetchall()
        await conn.close()
        return users
    except aiosqlite.Error as e:
        print(f"Database error: {e}")
        return []

# Command handler to download the users table as an XLSX file
async def download_users_command(message: Message, user_id: int) -> None:
    """Command handler for downloading users as an XLSX file."""
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("Sizda foydalanuvchilar ro'yxatini yuklab olish uchun ruxsat yo'q.")
        return

    users = await get_all_users()
    if not users:
        await message.answer("Foydalanuvchilar jadvali topilmadi.")
        return

    # Create 'data' directory if it doesn't exist
    data_folder = 'data'
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)

    # Generate XLSX file path inside the 'data' folder
    file_path = os.path.join(data_folder, 'users.xlsx')

    # Generate XLSX file with xlsxwriter
    with xlsxwriter.Workbook(file_path) as workbook:
            worksheet = workbook.add_worksheet()
            headers = ['ID', 'Telegram User ID', 'Telegram Username', 'Roles', 'Admin', 'Seller']
            worksheet.write_row(0, 0, headers)

            for row_num, user in enumerate(users, start=1):
                worksheet.write_row(row_num, 0, user)

    # Use FSInputFile to send the file
    input_file = types.FSInputFile(file_path)
    caption = f"Foydalanuvchilar ro'yxati: {time.strftime('%d-%m-%Y', time.localtime())} sanasidagi"
    await message.answer_document(input_file, caption=caption)