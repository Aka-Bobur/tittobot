import logging
import aiosqlite
from aiogram import Dispatcher
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from functions.admin_database import is_user_admin, connect_to_db
from keyboards.product_inlinekeys import delete_product_confirmation_keyboard

class DeleteProductStates(StatesGroup):
    waiting_for_product_id = State()
    waiting_for_confirmation = State()

async def initiate_delete_product(message: Message, state: FSMContext, user_id: int) -> None:
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("You do not have permission to delete a product.")
        return
    
    await message.answer("Please provide the Product ID of the product you want to delete:")
    await state.set_state(DeleteProductStates.waiting_for_product_id)
    logging.warning(f"User {user_id} initiated delete product process.")

async def process_delete_product_id(message: Message, state: FSMContext) -> None:
    del_product_id = message.text.strip()
    logging.warning(f"Received delete product ID: {del_product_id}")
    
    if not del_product_id.isdigit():  # Basic validation for product ID
        await message.answer("Invalid product ID. Please enter a numeric value.")
        return
    logging.warning(f"Checking product existence for ID: {del_product_id}")
    
    # Check if the user exists in the database
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT COUNT(*) FROM storage WHERE product_id = ?", (del_product_id,)) as cursor:
            count = await cursor.fetchone()
        logging.warning(f"Product count for ID {del_product_id}: {count[0]}")

        if count[0] == 0:
            await message.answer(f"Product with ID {del_product_id} does not exist.")
            return
        
        # Store the user_id in FSM data and ask for confirmation with inline keyboard
        await state.update_data(del_product_id=del_product_id)
        keyboard = delete_product_confirmation_keyboard()
        await message.answer(f"Are you sure you want to delete user with ID {del_product_id}?", reply_markup=keyboard)
        await state.set_state(DeleteProductStates.waiting_for_confirmation)
    except aiosqlite.Error as e:
        logging.error(f"Error while checking user existence: {e}")
        await message.answer(f"Error while checking user existence: {e}")
    finally:
        await conn.close()

async def callback_delete_confirmation(callback_query: CallbackQuery, state: FSMContext) -> None:
    confirmation = callback_query.data

    if confirmation == 'delete_confirm_yes':
        data = await state.get_data()
        del_product_id = data['del_product_id']

        try:
            conn = await connect_to_db()
            async with conn.execute("DELETE FROM storage WHERE product_id = ?", (del_product_id,)):
                await conn.commit()
            
            await callback_query.message.answer(f"Product with ID {del_product_id} has been successfully deleted.")
        except aiosqlite.Error as e:
            await callback_query.message.answer(f"Failed to delete product: {e}")
        finally:
            await conn.close()

        await state.clear()

    elif confirmation == 'delete_confirm_no':
        await callback_query.message.answer("Product deletion has been cancelled.")
        await state.clear()
    else:
        await callback_query.message.answer("Invalid action.")

# Registering handlers
def delete_product_handlers(dp: Dispatcher) -> None:
    dp.message.register(process_delete_product_id, StateFilter(DeleteProductStates.waiting_for_product_id))
    dp.callback_query.register(callback_delete_confirmation, StateFilter(DeleteProductStates.waiting_for_confirmation))
