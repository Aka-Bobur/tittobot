import logging
import aiosqlite
from aiogram import Dispatcher
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from functions.admin_database import is_user_admin, connect_to_db
from keyboards.expense_inlinekeys import delete_expense_confirmation_keyboard

class DeleteExpenseStates(StatesGroup):
    waiting_for_expense_id = State()
    waiting_for_confirmation = State()

async def initiate_delete_expense(message: Message, state: FSMContext, user_id: int) -> None:
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("You do not have permission to delete an Expense.")
        return

    await message.answer("Please provide the Expense ID of the Expense you want to delete:")
    await state.set_state(DeleteExpenseStates.waiting_for_expense_id)
    logging.warning(f"User {user_id} initiated delete Expense process.")

async def process_delete_Expense_id(message: Message, state: FSMContext) -> None:
    del_expense_id = message.text.strip()
    logging.warning(f"Received delete Expense ID: {del_expense_id}")

    if not del_expense_id.isdigit():  # Basic validation for Expense ID
        await message.answer("Invalid Expense ID. Please enter a numeric value.")
        return
    logging.warning(f"Checking Expense existence for ID: {del_expense_id}")
    
    # Check if the Expense exists in the database
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT COUNT(*) FROM expenses WHERE expense_id = ?", (del_expense_id,)) as cursor:
            count = await cursor.fetchone()
        logging.warning(f"Expense count for ID {del_expense_id}: {count[0]}")

        if count[0] == 0:
            await message.answer(f"Expense with ID {del_expense_id} does not exist.")
            return

        # Store the Expense_id in FSM data and ask for confirmation with inline keyboard
        await state.update_data(del_expense_id=del_expense_id)
        keyboard = delete_expense_confirmation_keyboard()
        await message.answer(f"Are you sure you want to delete the Expense with ID {del_expense_id}?", reply_markup=keyboard)
        await state.set_state(DeleteExpenseStates.waiting_for_confirmation)
    except aiosqlite.Error as e:
        logging.error(f"Error while checking Expense existence: {e}")
        await message.answer(f"Error while checking Expense existence: {e}")
    finally:
        await conn.close()

async def callback_delete_expense_confirmation(callback_query: CallbackQuery, state: FSMContext) -> None:
    confirmation = callback_query.data

    if confirmation == 'delete_confirm_yes':
        data = await state.get_data()
        del_expense_id = data['del_expense_id']

        try:
            conn = await connect_to_db()
            async with conn.execute("DELETE FROM Expenses WHERE Expense_id = ?", (del_expense_id,)):
                await conn.commit()

            await callback_query.message.edit_text(f"Expense with ID {del_expense_id} has been successfully deleted.")
        except aiosqlite.Error as e:
            await callback_query.message.answer(f"Failed to delete Expense: {e}")
        finally:
            await conn.close()

        await state.clear()

    elif confirmation == 'delete_confirm_no':
        await callback_query.message.edit_text("Expense deletion has been cancelled.")
        await state.clear()
    else:
        await callback_query.message.answer("Invalid action.")

# Registering handlers
def delete_expense_handlers(dp: Dispatcher) -> None:
    dp.message.register(process_delete_Expense_id, StateFilter(DeleteExpenseStates.waiting_for_expense_id))
    dp.callback_query.register(callback_delete_expense_confirmation, StateFilter(DeleteExpenseStates.waiting_for_confirmation))
