import logging
import aiosqlite
from aiogram import Dispatcher
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from functions.admin_database import is_user_admin, connect_to_db
from keyboards.product_inlinekeys import delete_order_confirmation_keyboard

class DeleteOrderStates(StatesGroup):
    waiting_for_order_id = State()
    waiting_for_confirmation = State()

async def initiate_delete_order(message: Message, state: FSMContext, user_id: int) -> None:
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("You do not have permission to delete an order.")
        return

    await message.answer("Please provide the Order ID of the order you want to delete:")
    await state.set_state(DeleteOrderStates.waiting_for_order_id)
    logging.warning(f"User {user_id} initiated delete order process.")

async def process_delete_order_id(message: Message, state: FSMContext) -> None:
    del_order_id = message.text.strip()
    logging.warning(f"Received delete order ID: {del_order_id}")

    if not del_order_id.isdigit():  # Basic validation for order ID
        await message.answer("Invalid order ID. Please enter a numeric value.")
        return
    logging.warning(f"Checking order existence for ID: {del_order_id}")
    
    # Check if the order exists in the database
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT COUNT(*) FROM orders WHERE order_id = ?", (del_order_id,)) as cursor:
            count = await cursor.fetchone()
        logging.warning(f"Order count for ID {del_order_id}: {count[0]}")

        if count[0] == 0:
            await message.answer(f"Order with ID {del_order_id} does not exist.")
            return

        # Store the order_id in FSM data and ask for confirmation with inline keyboard
        await state.update_data(del_order_id=del_order_id)
        keyboard = delete_order_confirmation_keyboard()
        await message.answer(f"Are you sure you want to delete the order with ID {del_order_id}?", reply_markup=keyboard)
        await state.set_state(DeleteOrderStates.waiting_for_confirmation)
    except aiosqlite.Error as e:
        logging.error(f"Error while checking order existence: {e}")
        await message.answer(f"Error while checking order existence: {e}")
    finally:
        await conn.close()

async def callback_delete_order_confirmation(callback_query: CallbackQuery, state: FSMContext) -> None:
    confirmation = callback_query.data

    if confirmation == 'delete_confirm_yes':
        data = await state.get_data()
        del_order_id = data['del_order_id']

        try:
            conn = await connect_to_db()
            async with conn.execute("DELETE FROM orders WHERE order_id = ?", (del_order_id,)):
                await conn.commit()

            await callback_query.message.answer(f"Order with ID {del_order_id} has been successfully deleted.")
        except aiosqlite.Error as e:
            await callback_query.message.answer(f"Failed to delete order: {e}")
        finally:
            await conn.close()

        await state.clear()

    elif confirmation == 'delete_confirm_no':
        await callback_query.message.answer("Order deletion has been cancelled.")
        await state.clear()
    else:
        await callback_query.message.answer("Invalid action.")

# Registering handlers
def delete_order_handlers(dp: Dispatcher) -> None:
    dp.message.register(process_delete_order_id, StateFilter(DeleteOrderStates.waiting_for_order_id))
    dp.callback_query.register(callback_delete_order_confirmation, StateFilter(DeleteOrderStates.waiting_for_confirmation))
