import logging
import aiosqlite
from aiogram import Dispatcher
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from functions.admin_database import is_user_admin, connect_to_db
from keyboards.newuser_inlinekeys import delete_user_confirmation_keyboard

class DeleteUserStates(StatesGroup):
    waiting_for_user_id = State()
    waiting_for_confirmation = State()

async def initiate_delete_user(message: Message, state: FSMContext, user_id: int) -> None:
    is_admin = await is_user_admin(user_id)
    if not is_admin:
        await message.answer("You do not have permission to delete a user.")
        return
    
    await message.answer("Please provide the Telegram user ID of the user you want to delete:")
    await state.set_state(DeleteUserStates.waiting_for_user_id)
    logging.warning(f"User {user_id} initiated delete user process.")

async def process_delete_user_id(message: Message, state: FSMContext) -> None:
    del_user_id = message.text.strip()
    logging.warning(f"Received delete user ID: {del_user_id}")
    
    if not del_user_id.isdigit():  # Basic validation for user ID
        await message.answer("Invalid user ID. Please enter a numeric value.")
        return
    logging.warning(f"Checking user existence for ID: {del_user_id}")
    
    # Check if the user exists in the database
    try:
        conn = await connect_to_db()
        async with conn.execute("SELECT COUNT(*) FROM users WHERE telegram_user_id = ?", (del_user_id,)) as cursor:
            count = await cursor.fetchone()
        logging.warning(f"User count for ID {del_user_id}: {count[0]}")

        if count[0] == 0:
            await message.answer(f"User with ID {del_user_id} does not exist.")
            return
        
        # Store the user_id in FSM data and ask for confirmation with inline keyboard
        await state.update_data(del_user_id=del_user_id)
        keyboard = delete_user_confirmation_keyboard()
        await message.answer(f"Are you sure you want to delete user with ID {del_user_id}?", reply_markup=keyboard)
        await state.set_state(DeleteUserStates.waiting_for_confirmation)
    except aiosqlite.Error as e:
        logging.error(f"Error while checking user existence: {e}")
        await message.answer(f"Error while checking user existence: {e}")
    finally:
        await conn.close()

async def callback_delete_confirmation(callback_query: CallbackQuery, state: FSMContext) -> None:
    confirmation = callback_query.data

    if confirmation == 'delete_confirm_yes':
        data = await state.get_data()
        del_user_id = data['del_user_id']

        try:
            conn = await connect_to_db()
            async with conn.execute("DELETE FROM users WHERE telegram_user_id = ?", (del_user_id,)):
                await conn.commit()
            
            await callback_query.message.edit_text(f"User with ID {del_user_id} has been successfully deleted.")
        except aiosqlite.Error as e:
            await callback_query.message.answer(f"Failed to delete user: {e}")
        finally:
            await conn.close()

        await state.clear()

    elif confirmation == 'delete_confirm_no':
        await callback_query.message.answer("User deletion has been cancelled.")
        await state.clear()
    else:
        await callback_query.message.answer("Invalid action.")

# Registering handlers
def delete_user_register_handlers(dp: Dispatcher) -> None:
    dp.message.register(process_delete_user_id, StateFilter(DeleteUserStates.waiting_for_user_id))
    dp.callback_query.register(callback_delete_confirmation, StateFilter(DeleteUserStates.waiting_for_confirmation))
